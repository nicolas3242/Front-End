-- DevFox v13 -> v14
-- Remove somente atividades de HTML/CSS que foram vinculadas incorretamente
-- à trilha JavaScript Básico. Não altera módulos, trilhas ou outras atividades.
SET NAMES utf8mb4;
START TRANSACTION;

DELETE FROM casos_teste
WHERE atividade_id BETWEEN 1019 AND 1026;

DELETE FROM alternativas
WHERE atividade_id BETWEEN 1019 AND 1026;

DELETE FROM atividades
WHERE id BETWEEN 1019 AND 1026
  AND titulo IN (
    'Tag de título',
    'Link HTML',
    'Texto alternativo',
    'Rótulo do campo',
    'Seletor de classe',
    'Tamanho da fonte',
    'Espaço externo',
    'Alinhamento flex'
  );

COMMIT;
