-- DevFox v14 -> v15
-- Remove somente as questões complementares de JavaScript que ficaram
-- associadas incorretamente aos módulos de HTML e CSS.
SET NAMES utf8mb4;
START TRANSACTION;

DELETE FROM alternativas
WHERE atividade_id BETWEEN 1008 AND 1018;

DELETE FROM casos_teste
WHERE atividade_id BETWEEN 1008 AND 1018;

DELETE FROM atividades
WHERE id BETWEEN 1008 AND 1018
  AND titulo IN (
    'Declarando uma variável',
    'Tipo boolean',
    'Resto da divisão',
    'Comparação estrita',
    'Bloco alternativo',
    'Retorno da função',
    'Parâmetro',
    'Condição do while',
    'Incremento no for',
    'Primeiro índice',
    'Laços aninhados'
  );

COMMIT;
