-- =====================================================================
-- DevFox — Migração do schema v10 para v11
-- =====================================================================
-- Faça backup antes de executar. Rode uma única vez em banco v10.
-- Adiciona Python ao ENUM de linguagens e marca a trilha de Lógica para
-- usar o executor Pyodide. Esta migração NÃO substitui módulos/atividades
-- antigos; para receber o novo conteúdo pedagógico completo, use um banco
-- novo a partir de database/banco.sql. Preserve seus dados antes de recriar.
-- =====================================================================
SET NAMES utf8mb4;
USE devfox;

ALTER TABLE trilhas
    MODIFY COLUMN linguagem ENUM('javascript','html','python') NOT NULL DEFAULT 'javascript';

UPDATE trilhas
SET linguagem = 'python',
    descricao = 'Aprenda lógica com Python, do primeiro print às decisões com if, else e elif.'
WHERE titulo = 'Lógica de Programação';
