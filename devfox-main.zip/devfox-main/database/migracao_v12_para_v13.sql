-- DevFox — Migração v12 para v13
-- Ajustes pontuais da trilha JavaScript Básico
-- Atualiza bancos v12 existentes para a v13. Faça backup antes de executar.

START TRANSACTION;

-- Primeiras funções deve vir depois dos módulos de looping e arrays.
UPDATE modulos SET ordem = 9 WHERE id = 19 AND trilha_id = 4;
UPDATE modulos SET ordem = 4 WHERE id = 20 AND trilha_id = 4;
UPDATE modulos SET ordem = 5 WHERE id = 21 AND trilha_id = 4;
UPDATE modulos SET ordem = 6 WHERE id = 22 AND trilha_id = 4;
UPDATE modulos SET ordem = 7 WHERE id = 23 AND trilha_id = 4;
UPDATE modulos SET ordem = 10 WHERE id = 24 AND trilha_id = 4;
UPDATE modulos SET ordem = 11 WHERE id = 25 AND trilha_id = 4;
UPDATE modulos SET ordem = 12 WHERE id = 26 AND trilha_id = 4;
UPDATE modulos SET ordem = 13 WHERE id = 27 AND trilha_id = 4;

-- Essas atividades eram de HTML/CSS, mas estavam vinculadas à trilha JS.
DELETE FROM casos_teste WHERE atividade_id BETWEEN 1019 AND 1026;
DELETE FROM alternativas WHERE atividade_id BETWEEN 1019 AND 1026;
DELETE FROM atividades WHERE id BETWEEN 1019 AND 1026;

COMMIT;
