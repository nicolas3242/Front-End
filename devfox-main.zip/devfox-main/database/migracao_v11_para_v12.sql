-- =====================================================================
-- DevFox — Migração v11 para v12
-- Adiciona questões complementares com IDs exclusivos.
-- Pode ser executada novamente sem gerar erro de chave primária duplicada.
-- Faça backup do banco antes de executar.
-- =====================================================================

-- Migração v11 -> v12: atualização segura e repetível das questões das trilhas.
-- Não apaga tabelas nem dados de alunos. Faça backup antes de executar.
USE devfox;

INSERT IGNORE INTO atividades (id, modulo_id, titulo, enunciado, tipo, dificuldade, dica, xp_recompensa, ordem) VALUES
(1000, 1, 'Identificando uma saída', 'Qual código mostra o número 25 na saída do Python?', 'quiz', 'facil', NULL, 100, 5),
(1001, 1, 'Texto entre aspas', 'Qual comando exibe a palavra Oi como texto?', 'quiz', 'facil', NULL, 100, 5),
(1002, 2, 'Tipo texto', 'Qual valor é do tipo string em Python?', 'quiz', 'facil', NULL, 100, 5),
(1003, 2, 'Atualizando uma variável', 'Depois de x = 4 e x = x + 3, qual é o valor de x?', 'quiz', 'facil', NULL, 100, 5),
(1004, 3, 'Resto da divisão', 'Qual é o resultado de 10 % 3 em Python?', 'quiz', 'facil', NULL, 100, 5),
(1005, 3, 'Comparação maior que', 'Qual expressão verifica se idade é maior que 17?', 'quiz', 'facil', NULL, 100, 5),
(1006, 4, 'Condição do if', 'Qual símbolo deve aparecer no final da linha if idade >= 18 em Python?', 'quiz', 'facil', NULL, 100, 5),
(1007, 4, 'Bloco indentado', 'Em Python, onde deve ficar o print dentro de um if?', 'quiz', 'facil', NULL, 100, 5),
(1019, 16, 'Tag de título', 'Qual tag representa o título principal de uma página HTML?', 'quiz', 'facil', NULL, 100, 5),
(1020, 17, 'Link HTML', 'Qual atributo de <a> define o endereço do link?', 'quiz', 'facil', NULL, 100, 5),
(1021, 18, 'Texto alternativo', 'Para que serve o atributo alt em uma imagem?', 'quiz', 'facil', NULL, 100, 5),
(1022, 19, 'Rótulo do campo', 'Qual atributo do label conecta o rótulo ao id de um input?', 'quiz', 'facil', NULL, 100, 5),
(1023, 21, 'Seletor de classe', 'Qual seletor CSS aplica estilo a class="cartao"?', 'quiz', 'facil', NULL, 100, 5),
(1024, 22, 'Tamanho da fonte', 'Qual propriedade CSS altera o tamanho do texto?', 'quiz', 'facil', NULL, 100, 5),
(1025, 23, 'Espaço externo', 'Qual propriedade cria espaço fora da borda de um elemento?', 'quiz', 'facil', NULL, 100, 5),
(1026, 24, 'Alinhamento flex', 'Qual propriedade distribui itens ao longo do eixo principal de um contêiner flex?', 'quiz', 'facil', NULL, 100, 5),
(1027, 26, 'Escopo de bloco', 'Uma variável let declarada dentro de um if pode ser usada fora das chaves desse if?', 'quiz', 'facil', NULL, 100, 5),
(1028, 27, 'Callback', 'O que é um callback?', 'quiz', 'facil', NULL, 100, 5),
(1029, 28, 'Método map', 'O que o método map normalmente devolve?', 'quiz', 'facil', NULL, 100, 5),
(1030, 29, 'Método de objeto', 'Como se chama uma função armazenada como propriedade de um objeto?', 'quiz', 'facil', NULL, 100, 5),
(1031, 31, 'Inverter texto', 'Qual sequência pode inverter os caracteres de uma string texto?', 'quiz', 'facil', NULL, 100, 5),
(1032, 32, 'Último dígito', 'Qual expressão obtém o último dígito de um número inteiro positivo n?', 'quiz', 'facil', NULL, 100, 5),
(1033, 33, 'Array sem duplicados', 'Qual estrutura pode ajudar a guardar valores únicos de um array?', 'quiz', 'facil', NULL, 100, 5),
(1034, 34, 'Ordenação numérica', 'Para ordenar números em ordem crescente com sort, qual comparação é adequada?', 'quiz', 'facil', NULL, 100, 5);

-- Questão complementar do módulo de decisões em JavaScript.
INSERT IGNORE INTO atividades (id, modulo_id, titulo, enunciado, tipo, dificuldade, dica, xp_recompensa, ordem) VALUES
(1035, 8, 'Operador lógico', 'Qual operador lógico exige que as duas condições sejam verdadeiras em JavaScript?', 'quiz', 'facil', NULL, 100, 5);

INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1000, 'print(25)', 1, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1000 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1000, 'mostrar(25)', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1000 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1000, 'output = 25', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1000 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1000, 'echo 25', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1000 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1001, 'print(Oi)', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1001 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1001, 'print("Oi")', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1001 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1001, 'print = "Oi"', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1001 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1001, 'text("Oi")', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1001 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1002, '42', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1002 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1002, '3.5', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1002 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1002, '"DevFox"', 1, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1002 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1002, 'True', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1002 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1003, '3', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1003 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1003, '4', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1003 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1003, '7', 1, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1003 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1003, '43', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1003 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1004, '0', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1004 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1004, '1', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1004 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1004, '3', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1004 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1004, '3.33', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1004 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1005, 'idade = 17', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1005 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1005, 'idade > 17', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1005 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1005, 'idade + 17', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1005 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1005, 'idade != 17', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1005 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1006, ';', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1006 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1006, '{', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1006 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1006, ':', 1, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1006 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1006, '=>', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1006 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1007, 'Na mesma coluna do if', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1007 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1007, 'Com indentação dentro do bloco', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1007 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1007, 'Sempre no fim do arquivo', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1007 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1007, 'Entre chaves', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1007 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1019, '<head>', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1019 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1019, '<h1>', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1019 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1019, '<title>', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1019 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1019, '<p>', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1019 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1020, 'src', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1020 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1020, 'alt', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1020 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1020, 'href', 1, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1020 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1020, 'target', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1020 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1021, 'Mudar o tamanho', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1021 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1021, 'Descrever a imagem quando ela não aparece e apoiar acessibilidade', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1021 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1021, 'Criar um link automaticamente', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1021 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1021, 'Definir a cor da imagem', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1021 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1022, 'name', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1022 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1022, 'for', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1022 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1022, 'href', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1022 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1022, 'action', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1022 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1023, '#cartao', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1023 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1023, '.cartao', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1023 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1023, 'cartao()', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1023 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1023, '*cartao', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1023 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1024, 'font-style', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1024 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1024, 'text-align', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1024 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1024, 'font-size', 1, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1024 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1024, 'text-weight', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1024 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1025, 'padding', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1025 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1025, 'margin', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1025 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1025, 'border', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1025 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1025, 'outline', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1025 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1026, 'justify-content', 1, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1026 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1026, 'font-align', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1026 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1026, 'text-items', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1026 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1026, 'position', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1026 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1027, 'Sim, sempre', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1027 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1027, 'Não, ela fica limitada ao bloco', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1027 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1027, 'Só se for número', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1027 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1027, 'Somente com console.log', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1027 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1028, 'Uma função passada para outra função', 1, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1028 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1028, 'Um tipo de array', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1028 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1028, 'Uma variável global', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1028 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1028, 'Um laço que não termina', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1028 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1029, 'O primeiro item encontrado', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1029 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1029, 'Um novo array com os resultados da transformação', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1029 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1029, 'Um boolean', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1029 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1029, 'Sempre um número', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1029 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1030, 'Parâmetro', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1030 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1030, 'Método', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1030 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1030, 'Índice', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1030 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1030, 'Callback obrigatório', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1030 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1031, 'texto.reverse()', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1031 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1031, 'texto.split("").reverse().join("")', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1031 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1031, 'texto.sort()', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1031 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1031, 'texto.map()', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1031 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1032, 'Math.floor(n / 10)', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1032 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1032, 'n % 10', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1032 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1032, 'n * 10', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1032 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1032, 'n / 10', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1032 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1033, 'Set', 1, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1033 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1033, 'Math', 0, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1033 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1033, 'String', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1033 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1033, 'Boolean', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1033 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1034, '(a, b) => b - a', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1034 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1034, '(a, b) => a - b', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1034 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1034, '(a, b) => a === b', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1034 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1034, '(a, b) => a + b', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1034 AND ordem = 4);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1035, '||', 0, 1 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1035 AND ordem = 1);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1035, '&&', 1, 2 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1035 AND ordem = 2);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1035, '!', 0, 3 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1035 AND ordem = 3);
INSERT INTO alternativas (atividade_id, texto, correta, ordem) SELECT 1035, '=', 0, 4 WHERE NOT EXISTS (SELECT 1 FROM alternativas WHERE atividade_id = 1035 AND ordem = 4);
